# the-movie

With React and ES6 from the move api.

## Screens

- [ ] Home
- [ ] TV Shows
- [ ] Search
- [ ] Detail
